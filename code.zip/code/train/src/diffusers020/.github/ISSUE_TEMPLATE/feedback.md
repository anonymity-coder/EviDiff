---
name: "💬 Feedback about API Design"
about: Give feedback about the current API design
title: ''
labels: ''
assignees: ''

---

**What API design would you like to have changed or added to the library? Why?**

**What use case would this enable or better enable? Can you give us a code example?**
