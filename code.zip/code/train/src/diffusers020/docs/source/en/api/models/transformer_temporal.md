# Transformer Temporal

A Transformer model for video-like data.

## TransformerTemporalModel

[[autodoc]] models.transformer_temporal.TransformerTemporalModel

## TransformerTemporalModelOutput

[[autodoc]] models.transformer_temporal.TransformerTemporalModelOutput