import torch
from diffusers import StableDiffusionPipeline

model_id = "EviDiff"
device = "cuda:0"

pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float32)
pipe = pipe.to(device)

prompt = "A small cat."
image = pipe(prompt).images[0]
image.save(str(i) + ".png")